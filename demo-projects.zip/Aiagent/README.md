# AI 教学助手（Aiagent）

基于 **Flask + 火山方舟 Doubao 大模型** 的智能教学平台，覆盖"课程 / 班级 / 作业 / 答题 / 批改 / AI 对话"全流程，提供**教师端**与**学生端**两套页面。

## 功能概览

- **课程与班级管理**：课程的增删改查、班级成员维护
- **作业管理**：教师创建作业、手工录入题目，或由大模型**一键生成题目**
- **学生端**：查看作业列表、在线作答、提交答卷
- **AI 批改**：对提交的答卷调用大模型评分并给出评语，教师端可查看待批改数量与批改结果
- **AI 对话**：多轮会话（历史上下文可配置），支持 **SSE 流式**输出
- **离线演示模式**：`MOCK_LLM=1` 时使用本地模拟模型，无需 API Key 即可完整演示

## 技术栈

| 层次 | 技术 |
|---|---|
| 后端 | Python 3.10+、Flask 3.1、flask-cors |
| 数据库 | MySQL 8.4、PyMySQL、DBUtils 连接池 |
| 大模型 | 火山方舟 Doubao（OpenAI 兼容 SDK，`openai>=1.80`） |
| 流式输出 | 原生 SSE（`app/utils/sse.py`） |
| 前端 | 原生 HTML / CSS / JavaScript（`static/`，含 axios、marked、DOMPurify） |
| 部署 | Dockerfile + docker-compose、Gunicorn |

## 目录结构

```
app/
  __init__.py        # 应用工厂：等待数据库就绪 → 建连接池 → 幂等建表/种子数据 → 注册路由
  config.py          # 环境变量配置
  db.py              # 数据库连接池
  bootstrap.py       # 启动初始化（等待 DB、执行 schema、写入种子数据）
  routes/            # 接口层：courses / classes / assignments / grading / messages / conversations / pages / health
  services/          # 业务层：课程、班级、作业、出题、提交、批改、对话
  models/            # DAO 层：课程、班级、作业、题目、提交、会话、消息
  llm/               # 模型适配：doubao（真实调用）/ mock_client（离线模拟）
  utils/             # SSE、序列化、校验
static/              # 教师端 index.html、学生端 student.html 及前端资源
sql/schema.sql       # 建表与种子数据（幂等）
scripts/smoke_teaching.py  # 教学流程冒烟脚本
docker-compose.yml   # MySQL 8.4 + Web 一键编排
```

## 快速开始（Docker，推荐）

```bash
cp .env.example .env          # 按需修改端口/口令；ARK_API_KEY 可留空
docker compose up -d --build
```

- 教师端：<http://localhost:8000/>
- 学生端：<http://localhost:8000/student>
- 健康检查：<http://localhost:8000/api/health>

默认 `MOCK_LLM=1`，直接可演示完整流程，无需申请模型 Key。

## 本地运行（不使用 Docker）

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# 将 .env 中 DB_HOST 改为 127.0.0.1，并准备好 MySQL 8.4 实例
python run.py                 # 默认 http://localhost:8000
```

## 主要环境变量

| 变量 | 说明 |
|---|---|
| `DB_HOST` / `DB_PORT` / `DB_USER` / `DB_PASSWORD` / `DB_NAME` | MySQL 连接配置 |
| `ARK_API_KEY` | 火山方舟 API Key；留空且 `MOCK_LLM=0` 时接口返回明确的配置错误 |
| `ARK_BASE_URL` / `ARK_MODEL` | 方舟网关地址与模型 ID |
| `MOCK_LLM` | `1`=本地模拟流式回复（离线演示）；`0`=真实调用 Doubao |
| `CONTEXT_LIMIT` / `SYSTEM_PROMPT` | 携带的历史消息条数与系统提示词 |
| `WEB_PORT` / `MYSQL_PORT` | 宿主机映射端口（默认 8000 / 3307） |

## 主要接口

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/health` | 健康检查 |
| GET/POST/PUT/DELETE | `/api/courses`、`/api/classes` | 课程 / 班级管理 |
| GET/POST | `/api/assignments`、`/api/generate-assignment` | 作业列表 / 创建 / AI 出题 |
| GET | `/api/student/assignments` | 学生作业列表 |
| GET | `/api/student/assignments/{id}/paper` | 获取答卷 |
| POST | `/api/student/assignments/{id}/submit` | 提交答卷 |
| GET | `/api/grading/submissions` | 待批改列表 |
| POST | `/api/grading/submissions/{id}/grade` | 触发 AI 批改 |
| POST | `/api/conversations/{id}/messages/stream` | AI 对话（SSE 流式） |
