# 个人项目 Demo 集

本压缩包包含三个可独立运行的完整项目，覆盖 **Python 后端 + 大模型应用**、**微信公众号机器人**、**Java 电商系统** 三条技术方向。

| 项目 | 一句话描述 | 技术栈 | 入口 |
|---|---|---|---|
| `Aiagent/` | AI 教学助手：课程 / 班级 / 作业 / AI 出题 / AI 批改 / 流式对话 | Python 3.10、Flask 3.1、MySQL 8.4、火山方舟 Doubao、Docker | `http://localhost:8000` |
| `wechat-money/` | 微信记账助手：用一句自然语言完成记账、查账、AI 消费分析 | Python 3.10、Flask、微信公众号、SQLite、Cloudflare Workers AI | 公众号聊天窗口 |
| `goods/` | 内容电商平台：种草笔记 / 文章内容带动商品转化，含买家前台 + 卖家中心 + 管理后台 | Java 21、Spring Boot 3.4.5、MyBatis-Plus、MySQL、Redis、RabbitMQ、Thymeleaf | `http://localhost:8081` |

每个目录下均有独立的 `README.md`，包含功能清单、目录结构、技术选型、环境变量与启动步骤。

## 快速体验建议

- **想先看效果最快**：`Aiagent`。默认 `MOCK_LLM=1`，执行 `cp .env.example .env && docker compose up -d --build` 后即可完整体验教师端 / 学生端与 AI 对话，无需申请大模型 Key。
- **想看业务复杂度**：`goods`（内容电商平台）。18 个控制器、三套角色页面、种草文章与商品关联、购物车 / 订单 / 评论 / 后台看板，适合展示工程化能力。已附 `sql/schema.sql`，执行后可直接用演示账号登录（需本机准备 MySQL、Redis、RabbitMQ）。
- **想看产品落地**：`wechat-money`。真实微信公众号交互形态，支持部署到 PythonAnywhere 长期运行。

## 说明

- 压缩包**不包含** `.git` 历史、`node_modules`、构建产物与运行期上传数据，仅保留源码、配置模板与静态资源。
- `goods` 的 `application.yml` 中数据库密码、邮箱授权码、Druid 口令等敏感信息已替换为**环境变量占位符**，按 README 注入即可运行。
- `goods` 已附带 `sql/schema.sql`（13 张表 + 演示数据），执行 `mysql -u root -p < sql/schema.sql` 即可初始化；`Aiagent` 与 `wechat-money` 均会自动初始化数据结构。
- `goods/frontend` 为早期 Vue3 实验版本，已废弃，未包含在演示包中；可演示界面为 Thymeleaf 页面。
